[{
      "content": "<div class='slide_inner'><img class='photo' src='images/carousel/fat-thin-man.jpg' alt='Bike'></div>",
      "content_button": "<div class='thumb'><img src='images/f2_thumb.jpg' alt='bike is nice'></div><p>Agile Carousel Place Holder</p>"
}, {
      "content": "<div class='slide_inner'><img class='photo' src='images/carousel/green.jpg' alt='Paint'></div>",
      "content_button": "<div class='thumb'><img src='images/f2_thumb.jpg' alt='bike is nice'></div><p>Agile Carousel Place Holder</p>"
}, {
      "content": "<div class='slide_inner'><img class='photo' src='images/carousel/sky.jpg' alt='Tunnel'></div>",
      "content_button": "<div class='thumb'><img src='images/f2_thumb.jpg' alt='bike is nice'></div><p>Agile Carousel Place Holder</p>"
}, {
      "content": "<div class='slide_inner'><img class='photo' src='images/carousel/young.jpg' alt='Bike'></div>",
      "content_button": "<div class='thumb'><img src='images/f2_thumb.jpg' alt='bike is nice'></div><p>Agile Carousel Place Holder</p>"
}, {
      "content": "<div class='slide_inner'><img class='photo' src='images/carousel/seed.jpg' alt='Paint'></div>",
      "content_button": "<div class='thumb'><img src='images/f2_thumb.jpg' alt='bike is nice'></div><p>Agile Carousel Place Holder</p>"
}, {
      "content": "<div class='slide_inner'><img class='photo' src='images/carousel/root.jpg' alt='Paint'></div>",
      "content_button": "<div class='thumb'><img src='images/f2_thumb.jpg' alt='bike is nice'></div><p>Agile Carousel Place Holder</p>"
}]