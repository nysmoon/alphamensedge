<?php
echo '<img id="header" src="images/header.jpg" title="alpha men\'s edge">';
?>