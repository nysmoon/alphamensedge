	<div id="icons">	
		<a href="https://www.facebook.com/AlphaMensEdgeNutrition"><img src="images/icons/fb.png"></a>
		<a style="float: left;" href="https://plus.google.com/100207534689828834828/posts"><img src="images/icons/g.png"></a>
		<a style="float: left;" href="http://www.linkedin.com/company/alpha-men's-edge-nutrition?trk=top_nav_home"><img src="images/icons/ln.png"></a>
	</div>