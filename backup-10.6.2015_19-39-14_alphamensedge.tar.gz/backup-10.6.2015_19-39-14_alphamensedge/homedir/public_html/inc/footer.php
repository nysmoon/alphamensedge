<?php
echo '<footer>Copyright &copy; Alpha Men\'s Edge Nutrition, ' . date('Y') . '. All rights reserved.</footer>';
?>