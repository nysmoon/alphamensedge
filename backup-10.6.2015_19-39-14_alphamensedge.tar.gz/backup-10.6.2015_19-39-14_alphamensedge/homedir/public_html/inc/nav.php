<nav id="main">
    <a href="index.php" title="Home" id="home"></a>
    <a href="contact.php" title="Contact" id="contact"></a>
    <a href="faq.php" title="Frequently asked questions" id="faq"></a>
    <a href="product-description.php" title="Product Description" id="product"></a>
    <a href="order-now.php" title="Order Now" id="order"></a>
</nav>