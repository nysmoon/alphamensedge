<!doctype html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<title>Contact Us | Alpha Men�s Edge</title>
	<meta name="description" content="Alpha Men�s Edge is the best testosterone booster for men to loose weight, think straight and feel great while increasing testosterone levels.">
	<meta name="keywords" content="Men�s Health, diet pills that work, best fat burner for men, weight loss for men, testosterone booster, natural testosterone booster, testosterone pills, best testosterone supplements, increase testosterone,">
	<meta name="viewport" content="width=device-width">
	
	<link rel="stylesheet" type="text/css" href="styles.css">
	<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
	<link rel="icon" href="images/favicon.ico" type="image/x-icon">	
	
<!--<link rel="shortcut icon" type="image/x-icon" href="images/icons/favicon.ico">-->

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-68539213-1', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body>
	<?php include('inc/icons.php');?>
<!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href="http://browsehappy.com/">Upgrade to a different browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to experience this site.</p><![endif]-->
  <div id="wrapper">
    <?php include('inc/header.php'); ?>
<!--    <div id="extend">
    </div>-->
    <div id="content">
      <?php include('inc/nav.php'); ?>
      <div id="top-bg"></div>
      <div id="content-wrapper">
	
	<h1  style="margin-bottom: 32px;">Contact Us</h1>
	<p>Need help placing an order? Contact us and we�ll be glad to help!</p>
        <?php include('inc/contact_form.php'); ?>
        <b>Contact us today at: </b>
        <ul>
            <li>info@alphamensedge.com</li>  
            <li>sales@alphamensedge.com</li>
            <li>orders@alphamensedge.com</li> 
        </p>
        <p>
            

 

     </div>
    </div>
	<div id="content-bottom"></div>
  </div>
  <?php include('inc/footer.php'); ?>
</body>
</html>